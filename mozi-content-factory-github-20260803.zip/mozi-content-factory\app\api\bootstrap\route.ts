import { db, ensureDb, id, now } from "@/lib/db";
import { apiError, ok } from "@/lib/http";
export async function POST(){try{await ensureDb();const count=await db.execute("SELECT COUNT(*) AS count FROM analysis_tasks");if(Number(count.rows[0].count)>0)return ok({seeded:false,message:"已有数据，未重复初始化"});const t=now(),taskId=id("analysis"),contentId=id("content"),w=id("version"),x=id("version");await db.batch([
 {sql:"INSERT INTO analysis_tasks (id,name,keywords,date_range_days,collection_limit,status,progress,article_count,insight_count,created_at,updated_at,completed_at) VALUES (?,?,?,7,50,'completed',100,50,5,?,?,?)",args:[taskId,"AI Agent 八月选题分析",JSON.stringify(["AI Agent"]),t,t,t]},
 {sql:"INSERT INTO contents (id,title,excerpt,body,status,style_selection,task_record,created_at,updated_at) VALUES (?,?,?,?,'pending_review',?,?,?,?)",args:[contentId,"普通人如何搭建第一个 AI Agent","从任务拆解到工作流搭建，一篇讲透智能体入门","真正有价值的 AI，不是陪你聊天，而是替你把事情做完。",JSON.stringify({writing:"专业易懂",visual:"editorial"}),JSON.stringify({currentStage:"review",gateChecklist:{titleBodyConfirmation:"pending_user_confirmation"}}),t,t]},
 {sql:"INSERT INTO content_versions (id,content_id,platform,title,body,status,created_at,updated_at) VALUES (?,?,?,?,?,'draft',?,?)",args:[w,contentId,"wechat","普通人如何搭建第一个 AI Agent","公众号版本正文",t,t]},
 {sql:"INSERT INTO content_versions (id,content_id,platform,title,body,status,created_at,updated_at) VALUES (?,?,?,?,?,'draft',?,?)",args:[x,contentId,"xiaohongshu","普通人如何搭建第一个 AI Agent","小红书版本正文",t,t]}
 ],"write");return ok({seeded:true,taskId,contentId},201);}catch(error){return apiError(error)}}
