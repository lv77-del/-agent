import { z } from "zod";
import { getRequestActor } from "@/lib/auth";
import { db, now } from "@/lib/db";
import { apiError, fail, ok } from "@/lib/http";
import { serializeContent } from "@/lib/serializers";
const schema=z.object({title:z.string().min(2).max(200).optional(),excerpt:z.string().max(500).optional(),body:z.string().optional(),status:z.enum(["draft","pending_review","pending_publish","publishing","published","failed","archived"]).optional()});
export async function PATCH(request:Request,c:{params:Promise<{id:string}>}){try{const actor=await getRequestActor(),{id}=await c.params,x=schema.parse(await request.json());const current=await db.execute({sql:"SELECT * FROM contents WHERE id=? AND workspace_id=?",args:[id,actor.workspaceId]});if(!current.rows[0])return fail("内容不存在",404);const r=current.rows[0];await db.execute({sql:"UPDATE contents SET title=?,excerpt=?,body=?,status=?,updated_at=? WHERE id=? AND workspace_id=?",args:[x.title??r.title,x.excerpt??r.excerpt,x.body??r.body,x.status??r.status,now(),id,actor.workspaceId]});const result=await db.execute({sql:`SELECT c.*, COALESCE(json_group_array(cv.platform),'[]') AS platforms FROM contents c LEFT JOIN content_versions cv ON cv.content_id=c.id WHERE c.id=? AND c.workspace_id=? GROUP BY c.id`,args:[id,actor.workspaceId]});return ok(serializeContent(result.rows[0]))}catch(error){return apiError(error)}}
