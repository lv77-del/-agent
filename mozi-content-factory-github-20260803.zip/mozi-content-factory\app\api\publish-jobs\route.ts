import { z } from "zod";
import { getRequestActor } from "@/lib/auth";
import { db, id, now, parseJson } from "@/lib/db";
import { apiError, fail, ok } from "@/lib/http";

const schema=z.object({contentVersionId:z.string().min(1),action:z.enum(["create_draft","publish"]).default("create_draft"),scheduledAt:z.string().datetime().optional()});

export async function GET(){try{
  const actor=await getRequestActor();
  const r=await db.execute({sql:"SELECT pj.*,cv.title FROM publish_jobs pj JOIN content_versions cv ON cv.id=pj.content_version_id WHERE pj.workspace_id=? ORDER BY pj.created_at DESC",args:[actor.workspaceId]});
  return ok(r.rows.map(x=>({...x,request_payload:parseJson(x.request_payload,{}),response_payload:parseJson(x.response_payload,{})})));
}catch(error){return apiError(error)}}

export async function POST(request:Request){try{
  const actor=await getRequestActor(),x=schema.parse(await request.json());
  const version=await db.execute({sql:"SELECT * FROM content_versions WHERE id=? AND workspace_id=?",args:[x.contentVersionId,actor.workspaceId]});
  if(!version.rows[0])return fail("平台内容版本不存在",404);
  const jobId=id("publish"),t=now();
  await db.execute({sql:"INSERT INTO publish_jobs (id,content_version_id,platform,action,status,scheduled_at,created_at,updated_at,workspace_id,created_by) VALUES (?,?,?,?,'pending_approval',?,?,?,?,?)",args:[jobId,x.contentVersionId,version.rows[0].platform,x.action,x.scheduledAt??null,t,t,actor.workspaceId,actor.userId]});
  return ok({id:jobId,status:"pending_approval",message:"发布任务已创建，确认后才会调用平台接口"},201);
}catch(error){return apiError(error)}}
