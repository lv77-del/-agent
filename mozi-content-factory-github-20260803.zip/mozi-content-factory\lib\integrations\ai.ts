import { spawn } from "node:child_process";

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

function codexPrompt(messages: ChatMessage[], json = false) {
  const conversation = messages.map((message) => `${message.role.toUpperCase()}:\n${message.content}`).join("\n\n");
  return [
    "完成下面的内容任务。不要调用工具，不要修改文件，只输出最终答案。",
    json ? "最终答案必须是合法 JSON；不要使用 Markdown 代码块，也不要添加解释。" : "直接输出结果，不要描述过程。",
    conversation,
  ].join("\n\n");
}

async function generateWithLocalCodex(messages: ChatMessage[], options: { json?: boolean; model?: string }) {
  const executable = process.env.CODEX_CLI_PATH || (process.platform === "win32" ? "codex.exe" : "codex");
  const model = options.model || process.env.AI_MODEL || "gpt-5.6-sol";
  const args = ["exec", "--json", "--ephemeral", "--skip-git-repo-check", "--sandbox", "read-only", "--ignore-user-config", "--ignore-rules", "--color", "never", "--model", model, "-"];
  return new Promise<string>((resolve, reject) => {
    const child = spawn(executable, args, { cwd: process.cwd(), windowsHide: true, stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    const timeout = setTimeout(() => child.kill(), 180_000);
    child.stdout.on("data", (chunk) => { stdout += String(chunk); });
    child.stderr.on("data", (chunk) => { stderr += String(chunk); });
    child.on("error", (error) => { clearTimeout(timeout); reject(error); });
    child.on("close", (code) => {
      clearTimeout(timeout);
      if (code !== 0) return reject(new Error(`本机 Codex 调用失败：${stderr.trim() || `退出码 ${code}`}`));
      const messages = stdout.split(/\r?\n/).flatMap((line) => {
        try {
          const event = JSON.parse(line);
          return event?.type === "item.completed" && event?.item?.type === "agent_message"
            ? [String(event.item.text || "")]
            : [];
        } catch { return []; }
      });
      const result = messages.at(-1)?.trim() || "";
      if (!result) return reject(new Error("本机 Codex 没有返回内容"));
      resolve(result);
    });
    child.stdin.end(codexPrompt(messages, options.json));
  });
}

export async function generateText(messages: ChatMessage[], options: { json?: boolean; model?: string } = {}) {
  if (process.env.AI_PROVIDER === "codex-cli") return generateWithLocalCodex(messages, options);
  const base = process.env.AI_BASE_URL?.replace(/\/$/, "") || "https://api.openai.com/v1";
  if (!process.env.AI_API_KEY) throw new Error("AI_API_KEY 尚未配置");
  const response = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${process.env.AI_API_KEY}` },
    body: JSON.stringify({ model: options.model || process.env.AI_MODEL || "gpt-5.6-sol", messages, response_format: options.json ? { type: "json_object" } : undefined }),
  });
  if (!response.ok) throw new Error(`AI 接口请求失败：${response.status}`);
  const data = await response.json();
  return String(data.choices?.[0]?.message?.content || "");
}
